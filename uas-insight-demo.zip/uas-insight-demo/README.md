# DAG / UAS Insight — website demo

Static site, no build step, no backend required. Five pages: `index.html`,
`services.html`, `about.html`, `insights.html`, `contact.html`, sharing
`css/styles.css`.

## Push it to GitHub and view it live (free, ~5 minutes)

```bash
cd uas-insight-demo
git init
git add .
git commit -m "Initial DAG/UAS Insight redesign demo"
git branch -M main
git remote add origin https://github.com/<your-username>/uas-insight-demo.git
git push -u origin main
```

Then in the repo on GitHub: **Settings → Pages → Source → Deploy from branch →
main / (root)**. GitHub gives you a URL like
`https://<your-username>.github.io/uas-insight-demo/` within a minute or two.
Share that link with anyone at DAG for feedback before touching the live
uas-insight.com domain at all.

## What's real vs. placeholder right now

- **Copy**: rewritten throughout, but treat it as a first draft — it's meant
  to fix the structural/consistency problems on the current site, not be
  final marketing copy.
- **Bill Daggett's bio**: cleaned up, but one item from the live site's bio
  reads like a typo ("purses") — flagged inline on the About page rather than
  guessed at. Confirm the real wording before this goes live.
- **Newsletter and ebook forms**: the HTML forms are wired up but don't submit
  anywhere yet (`action="#"`). Once you pick a CRM (HubSpot, Mailchimp,
  ConvertKit, etc.), swap the `action` and field `name`s to match their embed
  form, or replace the form with their embed snippet directly.
- **"Latest briefings" list on the Insights page**: three placeholder post
  titles, styled to match the KRAUV-style monthly recap format. Real posts
  replace these once you're publishing.
- **Team photo**: placeholder box. Drop a real headshot into `img/` and swap
  the `.team-photo` div for an `<img>` tag.
- **Stats in the hero** (4,500+ flight hours, 12 ANG locations): pulled
  directly from the existing About page copy, not invented.

## Design notes

Palette and type deliberately move away from the Wix template look: navy/paper
base with a single teal accent, a serif (Newsreader) for headlines against
IBM Plex Sans/Mono for body and data. Services page content is restructured
so it maps directly onto the Investors/Inventors/Entrants split used on the
homepage — on the live site today, the two pages list different, contradictory
service breakdowns.
